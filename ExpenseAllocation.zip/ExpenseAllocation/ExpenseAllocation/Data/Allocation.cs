﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpenseAllocation.Data
{
    internal static class Allocation
    {
        public const double Manager = 300;
        public const double Developer = 1000;
        public const double QATester = 500;
    }
}
